'use client'

import Link from 'next/link'
import { Sparkles, Facebook, MessageCircle } from 'lucide-react'

const footerLinks = {
  services: [
    { label: 'Quest Service', href: '/services#quest' },
    { label: 'Level Up Service', href: '/services#leveling' },
    { label: 'Gem Farming', href: '/services#gems' },
    { label: 'Map 100%', href: '/services#map100' },
  ],
  pages: [
    { label: 'Services', href: '/services' },
    { label: 'Prices', href: '/prices' },
    { label: 'Promotions', href: '/promotions' },
    { label: 'Queue Status', href: '/queue' },
  ],
  support: [
    { label: 'Book Now', href: '/booking' },
    { label: 'Contact Us', href: '/contact' },
    { label: 'Admin Panel', href: '/admin' },
  ],
}

export function Footer() {
  return (
    <footer className="border-t border-border/50 bg-card/50">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Brand */}
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center gap-2 text-xl font-bold gradient-text mb-4">
              <Sparkles className="w-6 h-6 text-primary" />
              NJ Shop
            </Link>
            <p className="text-sm text-muted-foreground mb-4">
              Professional Genshin Impact services. Fast, secure, and affordable.
            </p>
            <div className="flex items-center gap-3">
              <a 
                href="https://www.facebook.com/Nawaphon.Jamrasrak" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center hover:bg-primary/30 transition-colors"
              >
                <Facebook className="w-5 h-5 text-primary" />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center hover:bg-primary/30 transition-colors"
              >
                <MessageCircle className="w-5 h-5 text-primary" />
              </a>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-semibold mb-4">Services</h4>
            <ul className="space-y-2">
              {footerLinks.services.map((link) => (
                <li key={link.label}>
                  <Link 
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Pages */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {footerLinks.pages.map((link) => (
                <li key={link.label}>
                  <Link 
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-semibold mb-4">Support</h4>
            <ul className="space-y-2">
              {footerLinks.support.map((link) => (
                <li key={link.label}>
                  <Link 
                    href={link.href}
                    className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="pt-8 border-t border-border/50 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} NJ Shop. All rights reserved.
          </p>
          <p className="text-sm text-muted-foreground">
            FB: Nawaphon Jamrasrak
          </p>
        </div>
      </div>
    </footer>
  )
}
