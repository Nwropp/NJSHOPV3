'use client'

import React, { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react'
import type { Service, PriceItem, Promotion, QueueItem, BookingFormData } from './types'
import { services as defaultServices, priceItems as defaultPrices, promotions as defaultPromotions, sampleQueue } from './data'

interface DataContextType {
  // Data
  services: Service[]
  prices: PriceItem[]
  promotions: Promotion[]
  queue: QueueItem[]
  isLoading: boolean
  
  // Actions
  addQueueItem: (booking: BookingFormData) => string
  updateQueueStatus: (id: string, status: QueueItem['status']) => Promise<void>
  deleteQueueItem: (id: string) => Promise<void>
  updatePrice: (id: string, price: number) => Promise<void>
  addPromotion: (promo: Omit<Promotion, 'id'>) => Promise<void>
  updatePromotion: (id: string, promo: Partial<Promotion>) => Promise<void>
  deletePromotion: (id: string) => Promise<void>
  refreshData: () => Promise<void>
}

const DataContext = createContext<DataContextType | undefined>(undefined)

const STORAGE_KEYS = {
  PRICES: 'nj_prices',
  PROMOTIONS: 'nj_promotions',
  QUEUE: 'nj_queue',
}

export function DataProvider({ children }: { children: ReactNode }) {
  const [services] = useState<Service[]>(defaultServices)
  const [prices, setPrices] = useState<PriceItem[]>(defaultPrices)
  const [promotions, setPromotions] = useState<Promotion[]>(defaultPromotions)
  const [queue, setQueue] = useState<QueueItem[]>(sampleQueue)
  const [isLoading, setIsLoading] = useState(true)

  // Load data from localStorage on mount
  useEffect(() => {
    const loadData = () => {
      try {
        const savedPrices = localStorage.getItem(STORAGE_KEYS.PRICES)
        const savedPromos = localStorage.getItem(STORAGE_KEYS.PROMOTIONS)
        const savedQueue = localStorage.getItem(STORAGE_KEYS.QUEUE)

        if (savedPrices) setPrices(JSON.parse(savedPrices))
        if (savedPromos) setPromotions(JSON.parse(savedPromos))
        if (savedQueue) setQueue(JSON.parse(savedQueue))
      } catch (error) {
        console.error('Error loading data:', error)
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [])

  // Save to localStorage whenever data changes
  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem(STORAGE_KEYS.PRICES, JSON.stringify(prices))
    }
  }, [prices, isLoading])

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem(STORAGE_KEYS.PROMOTIONS, JSON.stringify(promotions))
    }
  }, [promotions, isLoading])

  useEffect(() => {
    if (!isLoading) {
      localStorage.setItem(STORAGE_KEYS.QUEUE, JSON.stringify(queue))
    }
  }, [queue, isLoading])

  const generateId = () => `NJ${String(Date.now()).slice(-4)}`

  const addQueueItem = useCallback((booking: BookingFormData): string => {
    const id = generateId()
    const newItem: QueueItem = {
      id,
      name: booking.name,
      uid: booking.uid,
      service: booking.service,
      detail: booking.detail,
      contact: booking.contact,
      status: 'waiting',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    setQueue(prev => [...prev, newItem])
    return id
  }, [])

  const updateQueueStatus = useCallback(async (id: string, status: QueueItem['status']) => {
    setQueue(prev => prev.map(item => 
      item.id === id 
        ? { ...item, status, updatedAt: new Date().toISOString() }
        : item
    ))
  }, [])

  const deleteQueueItem = useCallback(async (id: string) => {
    setQueue(prev => prev.filter(item => item.id !== id))
  }, [])

  const updatePrice = useCallback(async (id: string, price: number) => {
    setPrices(prev => prev.map(item =>
      item.id === id ? { ...item, price } : item
    ))
  }, [])

  const addPromotion = useCallback(async (promo: Omit<Promotion, 'id'>) => {
    const newPromo: Promotion = {
      ...promo,
      id: `promo${Date.now()}`,
    }
    setPromotions(prev => [...prev, newPromo])
  }, [])

  const updatePromotion = useCallback(async (id: string, updates: Partial<Promotion>) => {
    setPromotions(prev => prev.map(promo =>
      promo.id === id ? { ...promo, ...updates } : promo
    ))
  }, [])

  const deletePromotion = useCallback(async (id: string) => {
    setPromotions(prev => prev.filter(promo => promo.id !== id))
  }, [])

  const refreshData = useCallback(async () => {
    setIsLoading(true)
    await new Promise(resolve => setTimeout(resolve, 500))
    setIsLoading(false)
  }, [])

  return (
    <DataContext.Provider value={{
      services,
      prices,
      promotions,
      queue,
      isLoading,
      addQueueItem,
      updateQueueStatus,
      deleteQueueItem,
      updatePrice,
      addPromotion,
      updatePromotion,
      deletePromotion,
      refreshData,
    }}>
      {children}
    </DataContext.Provider>
  )
}

export function useData() {
  const context = useContext(DataContext)
  if (!context) {
    throw new Error('useData must be used within a DataProvider')
  }
  return context
}
