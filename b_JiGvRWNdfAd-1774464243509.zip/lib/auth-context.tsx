'use client'

import React, { createContext, useContext, useState, useEffect, type ReactNode } from 'react'

interface User {
  username: string
  role: 'admin'
}

interface AuthContextType {
  user: User | null
  isLoading: boolean
  login: (username: string, password: string) => Promise<boolean>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Default credentials - Change these for production!
const DEFAULT_CREDENTIALS = {
  username: 'admin',
  password: 'nexus2024',
}

const AUTH_KEY = 'nexus_admin_auth'

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check for existing session
    const savedAuth = sessionStorage.getItem(AUTH_KEY)
    if (savedAuth) {
      try {
        setUser(JSON.parse(savedAuth))
      } catch {
        sessionStorage.removeItem(AUTH_KEY)
      }
    }
    setIsLoading(false)
  }, [])

  const login = async (username: string, password: string): Promise<boolean> => {
    // Simple authentication - Replace with Firebase Auth or your auth system
    if (username === DEFAULT_CREDENTIALS.username && password === DEFAULT_CREDENTIALS.password) {
      const userData: User = { username, role: 'admin' }
      setUser(userData)
      sessionStorage.setItem(AUTH_KEY, JSON.stringify(userData))
      return true
    }
    return false
  }

  const logout = () => {
    setUser(null)
    sessionStorage.removeItem(AUTH_KEY)
  }

  return (
    <AuthContext.Provider value={{ user, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
