export interface Service {
  id: string
  name: string
  description: string
  image: string
  color: string
  startingPrice: number
  unit: string
}

export interface PriceItem {
  id: string
  serviceId: string
  name: string
  price: number
  unit: string
  description?: string
}

export interface Promotion {
  id: string
  title: string
  description: string
  discount: string
  badge?: string
  validUntil: string
  active: boolean
  terms?: string[]
}

export interface QueueItem {
  id: string
  name: string
  uid: string
  service: string
  detail?: string
  contact: string
  status: 'waiting' | 'in-progress' | 'completed'
  createdAt: string
  updatedAt: string
}

export interface BookingFormData {
  name: string
  uid: string
  service: string
  detail: string
  contact: string
}
