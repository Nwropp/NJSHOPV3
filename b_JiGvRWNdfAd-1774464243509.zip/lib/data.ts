import type { Service, PriceItem, Promotion, QueueItem } from './types'

export const services: Service[] = [
  {
    id: 'quest',
    name: 'Quest Service',
    description: 'Professional quest completion for all regions. Fast and reliable service.',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/306_20240905182941-1-n9PmK7pRy7FyxBGBKyPBAQ5zZ4Hlyv.jpg',
    color: 'from-sky-400 to-blue-500',
    startingPrice: 30,
    unit: 'per quest'
  },
  {
    id: 'id-care',
    name: 'ID Care Service',
    description: 'Daily account care including logins, rewards collection, and maintenance.',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/287_20240804181055-1-powzzhaE7vP0EK6BQRb3iqHgySLIYZ.jpg',
    color: 'from-blue-400 to-cyan-500',
    startingPrice: 7.5,
    unit: 'per day'
  },
  {
    id: 'fishing',
    name: 'Fishing Service',
    description: 'Fishing assistance for all fish types. Efficient and professional.',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/19_20251215123159-y8P4UEvJniejV3d0nn7xTcRsKEcaVZ.jpg',
    color: 'from-pink-300 to-rose-400',
    startingPrice: 25,
    unit: 'per fish type'
  },
  {
    id: 'farming',
    name: 'Farming Service',
    description: 'Item collection, dungeon runs, and boss battles. Complete farming solutions.',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/305_20240905175438-2-1GVgwIhx79zfa9TP5EHy87qWRsuMZG.jpg',
    color: 'from-red-400 to-orange-500',
    startingPrice: 0.5,
    unit: 'per item'
  },
  {
    id: 'leveling',
    name: 'Level Up Service',
    description: 'Character and weapon leveling with tiered pricing for all level ranges.',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/304_20240905165952-1-XYJ7gjl8tkwq3kF2xWi88oyG6B9Kvi.jpg',
    color: 'from-pink-400 to-rose-500',
    startingPrice: 10,
    unit: 'per tier'
  },
  {
    id: 'gems',
    name: 'Gem Farming',
    description: 'In-game currency farming with various package sizes. Best rates guaranteed.',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/quality_restoration_25680703165749637-GwATfztU1QMRP1WaWcOjBRob3dovPp.jpg',
    color: 'from-blue-300 to-indigo-400',
    startingPrice: 9,
    unit: 'per package'
  },
  {
    id: 'map100',
    name: 'Map 100% Completion',
    description: 'Complete map exploration for all regions. 100% guaranteed completion.',
    image: 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/46_20250707202455-1-w9nlv1YrRL1Ty4wuTZTNAzSZQ8ifA8.jpg',
    color: 'from-green-400 to-emerald-500',
    startingPrice: 2,
    unit: 'per %'
  },
]

export const priceItems: PriceItem[] = [
  // Quest Service Prices
  { id: 'q1', serviceId: 'quest', name: 'Mondstad', price: 30, unit: 'per quest' },
  { id: 'q2', serviceId: 'quest', name: 'Liyue', price: 35, unit: 'per quest' },
  { id: 'q3', serviceId: 'quest', name: 'Inazuma', price: 40, unit: 'per quest' },
  { id: 'q4', serviceId: 'quest', name: 'Sumeru', price: 50, unit: 'per quest' },
  { id: 'q5', serviceId: 'quest', name: 'Fontaine', price: 50, unit: 'per quest' },
  { id: 'q6', serviceId: 'quest', name: 'Natlan', price: 55, unit: 'per quest' },
  { id: 'q7', serviceId: 'quest', name: 'Legendary Quest', price: 25, unit: 'per character' },
  
  // ID Care Service Prices
  { id: 'ic1', serviceId: 'id-care', name: 'Daily Care (1 day)', price: 7.5, unit: '', description: 'Daily tasks, BP daily, exploration, dungeon/boss' },
  { id: 'ic2', serviceId: 'id-care', name: 'Weekly Care (7 days)', price: 52.5, unit: '', description: 'Daily tasks, coin collection, BP daily, exploration, dungeon/boss' },
  { id: 'ic3', serviceId: 'id-care', name: 'Monthly Care (30 days)', price: 225, unit: '', description: 'Daily tasks, exploration, coin collection, abyss/theater, BP daily, dungeon/boss' },
  { id: 'ic4', serviceId: 'id-care', name: 'Event Completion', price: 150, unit: '-200', description: 'Complete special events with additional activities' },
  
  // Fishing Service Prices
  { id: 'f1', serviceId: 'fishing', name: 'Polearm Fish', price: 85, unit: '' },
  { id: 'f2', serviceId: 'fishing', name: 'Bow Fish', price: 60, unit: '' },
  { id: 'f3', serviceId: 'fishing', name: 'Other Fish Types', price: 25, unit: 'each' },
  { id: 'f4', serviceId: 'fishing', name: 'Sword Fish', price: 55, unit: '' },
  
  // Farming Service Prices
  { id: 'fm1', serviceId: 'farming', name: 'Flowers', price: 0.5, unit: 'per piece' },
  { id: 'fm2', serviceId: 'farming', name: 'Ores', price: 0.5, unit: 'per piece' },
  { id: 'fm3', serviceId: 'farming', name: 'Small Animals', price: 0.5, unit: 'each' },
  { id: 'fm4', serviceId: 'farming', name: 'Dungeon Run', price: 1, unit: 'per run' },
  { id: 'fm5', serviceId: 'farming', name: 'Boss Kill', price: 2, unit: 'per boss' },
  { id: 'fm6', serviceId: 'farming', name: 'Weekly Boss', price: 3, unit: 'per boss' },
  { id: 'fm7', serviceId: 'farming', name: '1-Star Drop Item', price: 0.25, unit: 'per piece' },
  { id: 'fm8', serviceId: 'farming', name: '2-Star Drop Item', price: 0.5, unit: 'per piece' },
  { id: 'fm9', serviceId: 'farming', name: '3-Star Drop Item', price: 1, unit: 'per piece' },
  { id: 'fm10', serviceId: 'farming', name: '4-Star Drop Item', price: 1.5, unit: 'per piece' },
  
  // Level Up Service Prices
  { id: 'lv1', serviceId: 'leveling', name: 'Character LV 1-40', price: 10, unit: '' },
  { id: 'lv2', serviceId: 'leveling', name: 'Character LV 40-50', price: 20, unit: '' },
  { id: 'lv3', serviceId: 'leveling', name: 'Character LV 50-60', price: 30, unit: '' },
  { id: 'lv4', serviceId: 'leveling', name: 'Character LV 60-70', price: 45, unit: '' },
  { id: 'lv5', serviceId: 'leveling', name: 'Character LV 70-80', price: 55, unit: '' },
  { id: 'lv6', serviceId: 'leveling', name: 'Character LV 80-90', price: 65, unit: '' },
  { id: 'lv7', serviceId: 'leveling', name: 'Character Full (LV 1-90)', price: 220, unit: '', description: 'Bundle discount included' },
  { id: 'lv8', serviceId: 'leveling', name: 'Weapon LV 1-40', price: 10, unit: '' },
  { id: 'lv9', serviceId: 'leveling', name: 'Weapon LV 40-50', price: 20, unit: '' },
  { id: 'lv10', serviceId: 'leveling', name: 'Weapon LV 50-60', price: 30, unit: '' },
  { id: 'lv11', serviceId: 'leveling', name: 'Weapon LV 60-70', price: 45, unit: '' },
  { id: 'lv12', serviceId: 'leveling', name: 'Weapon LV 70-80', price: 55, unit: '' },
  { id: 'lv13', serviceId: 'leveling', name: 'Weapon LV 80-90', price: 65, unit: '' },
  { id: 'lv14', serviceId: 'leveling', name: 'Weapon Full (LV 1-90)', price: 220, unit: '', description: 'Bundle discount included' },
  
  // Gem Farming Prices - Small Packs
  { id: 'g1', serviceId: 'gems', name: '160 Gems', price: 9, unit: '' },
  { id: 'g2', serviceId: 'gems', name: '320 Gems', price: 18, unit: '' },
  { id: 'g3', serviceId: 'gems', name: '640 Gems', price: 36, unit: '' },
  { id: 'g4', serviceId: 'gems', name: '800 Gems', price: 45, unit: '' },
  { id: 'g5', serviceId: 'gems', name: '1000 Gems', price: 56, unit: '' },
  // Gem Farming Prices - Medium Packs
  { id: 'g6', serviceId: 'gems', name: '1280 Gems', price: 72, unit: '' },
  { id: 'g7', serviceId: 'gems', name: '1600 Gems', price: 90, unit: '' },
  { id: 'g8', serviceId: 'gems', name: '3200 Gems', price: 180, unit: '' },
  { id: 'g9', serviceId: 'gems', name: '4800 Gems', price: 270, unit: '' },
  { id: 'g10', serviceId: 'gems', name: '6400 Gems', price: 360, unit: '' },
  // Gem Farming Prices - Large Packs
  { id: 'g11', serviceId: 'gems', name: '8000 Gems', price: 510, unit: '' },
  { id: 'g12', serviceId: 'gems', name: '10000 Gems', price: 622, unit: '' },
  { id: 'g13', serviceId: 'gems', name: '12800 Gems', price: 780, unit: '' },
  { id: 'g14', serviceId: 'gems', name: '16000 Gems', price: 960, unit: '' },
  { id: 'g15', serviceId: 'gems', name: '20000 Gems', price: 1185, unit: '' },
  
  // Map 100% Completion Prices
  { id: 'm1', serviceId: 'map100', name: 'Mondstad (per %)', price: 2, unit: '' },
  { id: 'm2', serviceId: 'map100', name: 'Mondstad (Full 100%)', price: 180, unit: '' },
  { id: 'm3', serviceId: 'map100', name: 'Liyue (per %)', price: 2.5, unit: '' },
  { id: 'm4', serviceId: 'map100', name: 'Liyue (Full 100%)', price: 230, unit: '' },
  { id: 'm5', serviceId: 'map100', name: 'Inazuma (per %)', price: 2.5, unit: '' },
  { id: 'm6', serviceId: 'map100', name: 'Inazuma (Full 100%)', price: 230, unit: '' },
  { id: 'm7', serviceId: 'map100', name: 'Sumeru (per %)', price: 3, unit: '' },
  { id: 'm8', serviceId: 'map100', name: 'Sumeru (Full 100%)', price: 250, unit: '' },
  { id: 'm9', serviceId: 'map100', name: 'Fontaine (per %)', price: 3, unit: '' },
  { id: 'm10', serviceId: 'map100', name: 'Fontaine (Full 100%)', price: 270, unit: '' },
  { id: 'm11', serviceId: 'map100', name: 'Natlan (per %)', price: 3.5, unit: '' },
  { id: 'm12', serviceId: 'map100', name: 'Natlan (Full 100%)', price: 300, unit: '' },
  { id: 'm13', serviceId: 'map100', name: 'Add Quest Completion', price: 50, unit: '-200', description: 'Additional quest service' },
]

export const promotions: Promotion[] = [
  {
    id: 'promo1',
    title: 'New Customer Welcome',
    description: 'First-time customers get 15% off on any service!',
    discount: '15% OFF',
    badge: 'NEW',
    validUntil: '2025-12-31',
    active: true,
    terms: ['Valid for first order only', 'Cannot combine with other offers']
  },
  {
    id: 'promo2',
    title: 'Gem Rush Bonus',
    description: 'Get extra 10-30% gems when ordering large packs!',
    discount: '+10-30%',
    badge: 'HOT',
    validUntil: '2025-12-31',
    active: true,
    terms: ['Valid for 8000+ gem packages', 'Bonus gems delivered with order']
  },
  {
    id: 'promo3',
    title: 'Bundle Discount',
    description: 'Order 3+ services together and get 20% off total!',
    discount: '20% OFF',
    validUntil: '2025-12-31',
    active: true,
    terms: ['Minimum 3 services', 'Same order only']
  },
  {
    id: 'promo4',
    title: 'Monthly Care Special',
    description: 'Subscribe to monthly care and get free event completion!',
    discount: 'FREE EVENT',
    badge: 'BEST',
    validUntil: '2025-12-31',
    active: true,
    terms: ['Monthly care subscription required', 'One event per month']
  },
]

export const sampleQueue: QueueItem[] = [
  {
    id: 'NJ001',
    name: 'Player A',
    uid: '812345678',
    service: 'Quest Service',
    detail: 'Fontaine Region',
    contact: 'FB: Player A',
    status: 'in-progress',
    createdAt: '2025-03-25T10:30:00Z',
    updatedAt: '2025-03-25T14:00:00Z'
  },
  {
    id: 'NJ002',
    name: 'Player B',
    uid: '823456789',
    service: 'Level Up Service',
    detail: 'Character LV 60-90',
    contact: 'FB: Player B',
    status: 'waiting',
    createdAt: '2025-03-25T11:00:00Z',
    updatedAt: '2025-03-25T11:00:00Z'
  },
  {
    id: 'NJ003',
    name: 'Player C',
    uid: '834567890',
    service: 'Gem Farming',
    detail: '8000 Gems Package',
    contact: 'FB: Player C',
    status: 'waiting',
    createdAt: '2025-03-25T12:30:00Z',
    updatedAt: '2025-03-25T12:30:00Z'
  },
  {
    id: 'NJ004',
    name: 'Player D',
    uid: '845678901',
    service: 'Map 100%',
    detail: 'Sumeru Full Completion',
    contact: 'FB: Player D',
    status: 'completed',
    createdAt: '2025-03-24T09:00:00Z',
    updatedAt: '2025-03-24T18:00:00Z'
  },
]
