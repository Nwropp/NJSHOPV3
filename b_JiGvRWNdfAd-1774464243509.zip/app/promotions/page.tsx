'use client'

import Link from 'next/link'
import { DataProvider, useData } from '@/lib/data-context'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Gift, Clock, Sparkles, CheckCircle } from 'lucide-react'

function PromotionsContent() {
  const { promotions } = useData()
  const activePromotions = promotions.filter(p => p.active)

  return (
    <section className="py-20 pt-32">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-4">
            <Gift className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">Special Offers</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">Promotions</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Check out our latest promotions and save on your gaming services!
          </p>
        </div>

        {activePromotions.length === 0 ? (
          <div className="glass-card rounded-2xl p-12 text-center max-w-lg mx-auto">
            <Gift className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-xl font-bold mb-2">No Active Promotions</h2>
            <p className="text-muted-foreground">
              Check back later for exciting deals and offers!
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {activePromotions.map((promo, index) => (
              <div 
                key={promo.id}
                className="glass-card rounded-2xl overflow-hidden hover:scale-[1.02] transition-all duration-300 relative"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {/* Header */}
                <div className="bg-gradient-to-r from-primary/30 to-accent/30 p-6 relative">
                  {promo.badge && (
                    <Badge 
                      className="absolute top-4 right-4 bg-gradient-to-r from-primary to-accent text-primary-foreground"
                    >
                      {promo.badge}
                    </Badge>
                  )}
                  <div className="text-4xl font-bold gradient-text mb-2">
                    {promo.discount}
                  </div>
                  <h3 className="text-xl font-bold">{promo.title}</h3>
                </div>

                {/* Body */}
                <div className="p-6">
                  <p className="text-muted-foreground mb-4">
                    {promo.description}
                  </p>

                  {/* Terms */}
                  {promo.terms && promo.terms.length > 0 && (
                    <div className="space-y-2 mb-4">
                      {promo.terms.map((term, i) => (
                        <div key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                          <CheckCircle className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                          <span>{term}</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Footer */}
                  <div className="flex items-center justify-between pt-4 border-t border-border">
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      <span>Valid until {promo.validUntil}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="text-center mt-16">
          <div className="glass-card rounded-2xl p-8 max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">Want to use a promotion?</h2>
            <p className="text-muted-foreground mb-6">
              Mention the promotion code when booking your service!
            </p>
            <Link href="/booking">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-primary to-accent text-primary-foreground hover:opacity-90"
              >
                <Sparkles className="w-5 h-5 mr-2" />
                Book with Promo
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

export default function PromotionsPage() {
  return (
    <DataProvider>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main>
          <PromotionsContent />
        </main>
        <Footer />
      </div>
    </DataProvider>
  )
}
