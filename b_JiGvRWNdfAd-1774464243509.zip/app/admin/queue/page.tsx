'use client'

import { useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { useData } from '@/lib/data-context'
import { AdminSidebar } from '@/components/admin/sidebar'
import { AdminLoginForm } from '@/components/admin/login-form'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { cn } from '@/lib/utils'
import type { QueueItem } from '@/lib/types'
import { 
  Loader2, 
  Trash2,
  Search,
  Clock,
  CheckCircle2
} from 'lucide-react'

const statusConfig = {
  waiting: { label: 'Waiting', color: 'bg-amber-500/20 text-amber-400 border-amber-500/30', icon: Clock },
  'in-progress': { label: 'In Progress', color: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30', icon: Loader2 },
  completed: { label: 'Completed', color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30', icon: CheckCircle2 },
}

export default function AdminQueuePage() {
  const { user, isLoading: authLoading } = useAuth()
  const { queue, updateQueueStatus, deleteQueueItem, isLoading: dataLoading } = useData()
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')

  if (authLoading || dataLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!user) {
    return <AdminLoginForm />
  }

  const filteredQueue = queue.filter(item => {
    const matchesSearch = 
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.uid.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.service.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter
    
    return matchesSearch && matchesStatus
  })

  const handleStatusChange = async (id: string, newStatus: QueueItem['status']) => {
    await updateQueueStatus(id, newStatus)
  }

  const handleDelete = async (id: string) => {
    await deleteQueueItem(id)
  }

  const clearCompleted = async () => {
    const completedIds = queue.filter(q => q.status === 'completed').map(q => q.id)
    for (const id of completedIds) {
      await deleteQueueItem(id)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <AdminSidebar />
      
      <main className="lg:ml-64 p-4 lg:p-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold">Queue Management</h1>
            <p className="text-muted-foreground">Manage customer orders and status</p>
          </div>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="sm">
                <Trash2 className="w-4 h-4 mr-2" />
                Clear Completed
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="glass-card border-0">
              <AlertDialogHeader>
                <AlertDialogTitle>Clear Completed Orders?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete all completed orders. This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={clearCompleted} className="bg-destructive text-destructive-foreground">
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, ID, UID, or service..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bg-secondary/50 border-border/50"
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full md:w-48 bg-secondary/50 border-border/50">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="waiting">Waiting</SelectItem>
              <SelectItem value="in-progress">In Progress</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Queue List */}
        <Card className="glass-card border-0">
          <CardHeader>
            <CardTitle className="text-lg">All Orders ({filteredQueue.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {filteredQueue.length === 0 ? (
              <p className="text-center text-muted-foreground py-12">No orders found</p>
            ) : (
              <div className="space-y-4">
                {filteredQueue.map((item) => {
                  const config = statusConfig[item.status]
                  const StatusIcon = config.icon
                  
                  return (
                    <div 
                      key={item.id} 
                      className={cn(
                        'p-4 rounded-lg bg-secondary/30 border border-border/50',
                        item.status === 'in-progress' && 'ring-1 ring-cyan-500/30'
                      )}
                    >
                      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                        <div className="flex-1 grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                          <div>
                            <div className="text-xs text-muted-foreground mb-1">Order ID</div>
                            <div className="font-mono font-semibold">#{item.id}</div>
                          </div>
                          <div>
                            <div className="text-xs text-muted-foreground mb-1">Customer</div>
                            <div className="font-medium">{item.name}</div>
                            <div className="text-xs text-muted-foreground">UID: {item.uid}</div>
                          </div>
                          <div>
                            <div className="text-xs text-muted-foreground mb-1">Service</div>
                            <div className="font-medium">{item.service}</div>
                            {item.detail && (
                              <div className="text-xs text-muted-foreground">{item.detail}</div>
                            )}
                          </div>
                          <div>
                            <div className="text-xs text-muted-foreground mb-1">Contact</div>
                            <div className="text-sm">{item.contact}</div>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <Select
                            value={item.status}
                            onValueChange={(value) => handleStatusChange(item.id, value as QueueItem['status'])}
                          >
                            <SelectTrigger className={cn('w-40', config.color)}>
                              <div className="flex items-center gap-2">
                                <StatusIcon className={cn('w-3 h-3', item.status === 'in-progress' && 'animate-spin')} />
                                <SelectValue />
                              </div>
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="waiting">
                                <span className="flex items-center gap-2">
                                  <Clock className="w-3 h-3" /> Waiting
                                </span>
                              </SelectItem>
                              <SelectItem value="in-progress">
                                <span className="flex items-center gap-2">
                                  <Loader2 className="w-3 h-3" /> In Progress
                                </span>
                              </SelectItem>
                              <SelectItem value="completed">
                                <span className="flex items-center gap-2">
                                  <CheckCircle2 className="w-3 h-3" /> Completed
                                </span>
                              </SelectItem>
                            </SelectContent>
                          </Select>

                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent className="glass-card border-0">
                              <AlertDialogHeader>
                                <AlertDialogTitle>Delete Order?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This will permanently delete order #{item.id}. This action cannot be undone.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction 
                                  onClick={() => handleDelete(item.id)}
                                  className="bg-destructive text-destructive-foreground"
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>

                      <div className="mt-3 pt-3 border-t border-border/50 flex flex-wrap gap-4 text-xs text-muted-foreground">
                        <span>Created: {new Date(item.createdAt).toLocaleString()}</span>
                        <span>Updated: {new Date(item.updatedAt).toLocaleString()}</span>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
