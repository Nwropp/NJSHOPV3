'use client'

import { AuthProvider } from '@/lib/auth-context'
import { DataProvider } from '@/lib/data-context'

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <AuthProvider>
      <DataProvider>
        {children}
      </DataProvider>
    </AuthProvider>
  )
}
