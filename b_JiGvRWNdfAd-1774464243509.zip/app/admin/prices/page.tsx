'use client'

import { useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { useData } from '@/lib/data-context'
import { AdminSidebar } from '@/components/admin/sidebar'
import { AdminLoginForm } from '@/components/admin/login-form'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { cn } from '@/lib/utils'
import { Loader2, Save, Check } from 'lucide-react'

export default function AdminPricesPage() {
  const { user, isLoading: authLoading } = useAuth()
  const { services, prices, updatePrice, isLoading: dataLoading } = useData()
  const [activeTab, setActiveTab] = useState(services[0]?.id || '')
  const [editingPrices, setEditingPrices] = useState<Record<string, number>>({})
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set())

  if (authLoading || dataLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!user) {
    return <AdminLoginForm />
  }

  const filteredPrices = prices.filter(p => p.serviceId === activeTab)
  const activeService = services.find(s => s.id === activeTab)

  const handlePriceChange = (id: string, value: string) => {
    const numValue = parseFloat(value) || 0
    setEditingPrices(prev => ({ ...prev, [id]: numValue }))
  }

  const handleSave = async (id: string) => {
    const newPrice = editingPrices[id]
    if (newPrice !== undefined) {
      await updatePrice(id, newPrice)
      setSavedIds(prev => new Set(prev).add(id))
      setTimeout(() => {
        setSavedIds(prev => {
          const next = new Set(prev)
          next.delete(id)
          return next
        })
      }, 2000)
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent, id: string) => {
    if (e.key === 'Enter') {
      handleSave(id)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <AdminSidebar />
      
      <main className="lg:ml-64 p-4 lg:p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl lg:text-3xl font-bold">Price Management</h1>
          <p className="text-muted-foreground">Edit prices for all services. Changes are saved automatically.</p>
        </div>

        {/* Service Tabs */}
        <div className="flex flex-wrap gap-2 mb-6">
          {services.map((service) => (
            <Button
              key={service.id}
              variant={activeTab === service.id ? 'default' : 'outline'}
              size="sm"
              onClick={() => setActiveTab(service.id)}
              className={cn(
                'transition-all',
                activeTab === service.id && 'bg-gradient-to-r from-primary to-accent text-primary-foreground'
              )}
            >
              <span className="mr-2">{service.icon}</span>
              {service.name}
            </Button>
          ))}
        </div>

        {/* Price Table */}
        <Card className="glass-card border-0">
          <CardHeader className="border-b border-border/50">
            <div className="flex items-center gap-3">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${activeService?.color} flex items-center justify-center text-2xl`}>
                {activeService?.icon}
              </div>
              <div>
                <CardTitle>{activeService?.name}</CardTitle>
                <p className="text-sm text-muted-foreground">{activeService?.description}</p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y divide-border/50">
              {filteredPrices.map((item, index) => {
                const currentPrice = editingPrices[item.id] ?? item.price
                const isSaved = savedIds.has(item.id)
                
                return (
                  <div 
                    key={item.id}
                    className={cn(
                      'flex flex-col md:flex-row md:items-center justify-between p-4 md:p-6 gap-4',
                      index % 2 === 0 && 'bg-secondary/10'
                    )}
                  >
                    <div className="flex-1">
                      <div className="font-medium">{item.name}</div>
                      {item.description && (
                        <div className="text-sm text-muted-foreground">{item.description}</div>
                      )}
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">$</span>
                        <Input
                          type="number"
                          value={currentPrice}
                          onChange={(e) => handlePriceChange(item.id, e.target.value)}
                          onKeyDown={(e) => handleKeyDown(e, item.id)}
                          onBlur={() => handleSave(item.id)}
                          className="w-24 bg-secondary/50 border-border/50 text-right"
                          step="0.01"
                          min="0"
                        />
                        {item.unit && (
                          <span className="text-sm text-muted-foreground">{item.unit}</span>
                        )}
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleSave(item.id)}
                        className={cn(
                          'transition-all',
                          isSaved && 'text-emerald-400'
                        )}
                      >
                        {isSaved ? <Check className="w-4 h-4" /> : <Save className="w-4 h-4" />}
                      </Button>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>

        <p className="text-sm text-muted-foreground mt-4">
          Tip: Press Enter or click outside the input to save. Changes are reflected immediately on the website.
        </p>
      </main>
    </div>
  )
}
