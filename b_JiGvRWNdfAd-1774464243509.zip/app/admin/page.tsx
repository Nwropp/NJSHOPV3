'use client'

import { useAuth } from '@/lib/auth-context'
import { useData } from '@/lib/data-context'
import { AdminSidebar } from '@/components/admin/sidebar'
import { AdminLoginForm } from '@/components/admin/login-form'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import Link from 'next/link'
import { 
  Clock, 
  Loader2, 
  CheckCircle2, 
  ListOrdered,
  DollarSign,
  Gift,
  ArrowRight
} from 'lucide-react'

const statusConfig = {
  waiting: { label: 'Waiting', color: 'bg-amber-500/20 text-amber-400 border-amber-500/30' },
  'in-progress': { label: 'In Progress', color: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30' },
  completed: { label: 'Completed', color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' },
}

export default function AdminDashboard() {
  const { user, isLoading: authLoading } = useAuth()
  const { queue, promotions, services, isLoading: dataLoading } = useData()

  if (authLoading || dataLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!user) {
    return <AdminLoginForm />
  }

  const waitingCount = queue.filter(q => q.status === 'waiting').length
  const inProgressCount = queue.filter(q => q.status === 'in-progress').length
  const completedCount = queue.filter(q => q.status === 'completed').length
  const activePromos = promotions.filter(p => p.active).length
  const recentQueue = queue.slice(-5).reverse()

  const stats = [
    { 
      label: 'Total Orders', 
      value: queue.length, 
      icon: ListOrdered, 
      color: 'text-primary',
      bg: 'bg-primary/20'
    },
    { 
      label: 'Waiting', 
      value: waitingCount, 
      icon: Clock, 
      color: 'text-amber-400',
      bg: 'bg-amber-500/20'
    },
    { 
      label: 'In Progress', 
      value: inProgressCount, 
      icon: Loader2, 
      color: 'text-cyan-400',
      bg: 'bg-cyan-500/20'
    },
    { 
      label: 'Completed', 
      value: completedCount, 
      icon: CheckCircle2, 
      color: 'text-emerald-400',
      bg: 'bg-emerald-500/20'
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      <AdminSidebar />
      
      <main className="lg:ml-64 p-4 lg:p-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl lg:text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back, {user.username}</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map((stat) => (
            <Card key={stat.label} className="glass-card border-0">
              <CardContent className="p-4 lg:p-6">
                <div className="flex items-center gap-3">
                  <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center', stat.bg)}>
                    <stat.icon className={cn('w-5 h-5', stat.color)} />
                  </div>
                  <div>
                    <div className={cn('text-2xl font-bold', stat.color)}>{stat.value}</div>
                    <div className="text-xs text-muted-foreground">{stat.label}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Quick Actions & Recent Queue */}
        <div className="grid lg:grid-cols-2 gap-6">
          {/* Recent Queue */}
          <Card className="glass-card border-0">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-lg">Recent Orders</CardTitle>
              <Link href="/admin/queue">
                <Button variant="ghost" size="sm">
                  View All <ArrowRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </CardHeader>
            <CardContent>
              {recentQueue.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No orders yet</p>
              ) : (
                <div className="space-y-3">
                  {recentQueue.map((item) => (
                    <div key={item.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/30">
                      <div>
                        <div className="font-medium text-sm">{item.name}</div>
                        <div className="text-xs text-muted-foreground">{item.service}</div>
                      </div>
                      <Badge variant="outline" className={statusConfig[item.status].color}>
                        {statusConfig[item.status].label}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Links */}
          <Card className="glass-card border-0">
            <CardHeader>
              <CardTitle className="text-lg">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Link href="/admin/queue" className="block">
                <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                      <ListOrdered className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <div className="font-medium">Manage Queue</div>
                      <div className="text-xs text-muted-foreground">{queue.length} total orders</div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground" />
                </div>
              </Link>

              <Link href="/admin/prices" className="block">
                <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-emerald-500/20 flex items-center justify-center">
                      <DollarSign className="w-5 h-5 text-emerald-400" />
                    </div>
                    <div>
                      <div className="font-medium">Edit Prices</div>
                      <div className="text-xs text-muted-foreground">{services.length} services</div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground" />
                </div>
              </Link>

              <Link href="/admin/promotions" className="block">
                <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-pink-500/20 flex items-center justify-center">
                      <Gift className="w-5 h-5 text-pink-400" />
                    </div>
                    <div>
                      <div className="font-medium">Promotions</div>
                      <div className="text-xs text-muted-foreground">{activePromos} active</div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-muted-foreground" />
                </div>
              </Link>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
