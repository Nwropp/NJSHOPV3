'use client'

import { useState } from 'react'
import { useAuth } from '@/lib/auth-context'
import { useData } from '@/lib/data-context'
import { AdminSidebar } from '@/components/admin/sidebar'
import { AdminLoginForm } from '@/components/admin/login-form'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import { cn } from '@/lib/utils'
import type { Promotion } from '@/lib/types'
import { 
  Loader2, 
  Plus,
  Trash2,
  Edit,
  Gift,
  Calendar
} from 'lucide-react'

const emptyPromo: Omit<Promotion, 'id'> = {
  title: '',
  description: '',
  discount: '',
  badge: '',
  validUntil: new Date().toISOString().split('T')[0],
  active: true,
  terms: [],
}

export default function AdminPromotionsPage() {
  const { user, isLoading: authLoading } = useAuth()
  const { promotions, addPromotion, updatePromotion, deletePromotion, isLoading: dataLoading } = useData()
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingPromo, setEditingPromo] = useState<Promotion | null>(null)
  const [formData, setFormData] = useState<Omit<Promotion, 'id'>>(emptyPromo)
  const [termsInput, setTermsInput] = useState('')

  if (authLoading || dataLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    )
  }

  if (!user) {
    return <AdminLoginForm />
  }

  const handleOpenDialog = (promo?: Promotion) => {
    if (promo) {
      setEditingPromo(promo)
      setFormData({
        title: promo.title,
        description: promo.description,
        discount: promo.discount,
        badge: promo.badge || '',
        validUntil: promo.validUntil,
        active: promo.active,
        terms: promo.terms || [],
      })
      setTermsInput(promo.terms?.join('\n') || '')
    } else {
      setEditingPromo(null)
      setFormData(emptyPromo)
      setTermsInput('')
    }
    setIsDialogOpen(true)
  }

  const handleSave = async () => {
    const terms = termsInput.split('\n').filter(t => t.trim())
    const promoData = { ...formData, terms }

    if (editingPromo) {
      await updatePromotion(editingPromo.id, promoData)
    } else {
      await addPromotion(promoData)
    }
    setIsDialogOpen(false)
  }

  const handleToggleActive = async (id: string, active: boolean) => {
    await updatePromotion(id, { active })
  }

  const handleDelete = async (id: string) => {
    await deletePromotion(id)
  }

  return (
    <div className="min-h-screen bg-background">
      <AdminSidebar />
      
      <main className="lg:ml-64 p-4 lg:p-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold">Promotions</h1>
            <p className="text-muted-foreground">Manage special offers and discounts</p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={() => handleOpenDialog()} className="bg-gradient-to-r from-primary to-accent text-primary-foreground">
                <Plus className="w-4 h-4 mr-2" />
                Add Promotion
              </Button>
            </DialogTrigger>
            <DialogContent className="glass-card border-0 max-w-lg">
              <DialogHeader>
                <DialogTitle>{editingPromo ? 'Edit Promotion' : 'Add Promotion'}</DialogTitle>
                <DialogDescription>
                  {editingPromo ? 'Update the promotion details below.' : 'Create a new promotion for your customers.'}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Title *</Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      placeholder="e.g., Weekend Sale"
                      className="bg-secondary/50 border-border/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="discount">Discount *</Label>
                    <Input
                      id="discount"
                      value={formData.discount}
                      onChange={(e) => setFormData({ ...formData, discount: e.target.value })}
                      placeholder="e.g., 20% OFF"
                      className="bg-secondary/50 border-border/50"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description *</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Describe the promotion..."
                    className="bg-secondary/50 border-border/50"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="badge">Badge (optional)</Label>
                    <Input
                      id="badge"
                      value={formData.badge}
                      onChange={(e) => setFormData({ ...formData, badge: e.target.value })}
                      placeholder="e.g., HOT, NEW"
                      className="bg-secondary/50 border-border/50"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="validUntil">Valid Until *</Label>
                    <Input
                      id="validUntil"
                      type="date"
                      value={formData.validUntil}
                      onChange={(e) => setFormData({ ...formData, validUntil: e.target.value })}
                      className="bg-secondary/50 border-border/50"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="terms">Terms (one per line)</Label>
                  <Textarea
                    id="terms"
                    value={termsInput}
                    onChange={(e) => setTermsInput(e.target.value)}
                    placeholder="Enter terms and conditions..."
                    className="bg-secondary/50 border-border/50"
                    rows={3}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="active">Active</Label>
                  <Switch
                    id="active"
                    checked={formData.active}
                    onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Cancel</Button>
                <Button onClick={handleSave} className="bg-gradient-to-r from-primary to-accent text-primary-foreground">
                  {editingPromo ? 'Update' : 'Create'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Promotions Grid */}
        {promotions.length === 0 ? (
          <Card className="glass-card border-0">
            <CardContent className="p-12 text-center">
              <Gift className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No promotions yet. Create your first promotion!</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 gap-6">
            {promotions.map((promo) => (
              <Card 
                key={promo.id} 
                className={cn(
                  'glass-card border-0 overflow-hidden transition-all',
                  !promo.active && 'opacity-60'
                )}
              >
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                        <Gift className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{promo.title}</CardTitle>
                        {promo.badge && (
                          <Badge variant="secondary" className="mt-1 bg-primary/20 text-primary">
                            {promo.badge}
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="text-xl font-bold gradient-text">{promo.discount}</div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">{promo.description}</p>
                  
                  {promo.terms && promo.terms.length > 0 && (
                    <div className="text-xs text-muted-foreground mb-4 space-y-1">
                      {promo.terms.map((term, i) => (
                        <div key={i}>• {term}</div>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-4 border-t border-border/50">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Calendar className="w-3 h-3" />
                      Until {new Date(promo.validUntil).toLocaleDateString()}
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={promo.active}
                        onCheckedChange={(checked) => handleToggleActive(promo.id, checked)}
                      />
                      <Button variant="ghost" size="icon" onClick={() => handleOpenDialog(promo)}>
                        <Edit className="w-4 h-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" className="text-destructive hover:text-destructive hover:bg-destructive/10">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="glass-card border-0">
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Promotion?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will permanently delete the promotion &quot;{promo.title}&quot;. This action cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction 
                              onClick={() => handleDelete(promo.id)}
                              className="bg-destructive text-destructive-foreground"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
