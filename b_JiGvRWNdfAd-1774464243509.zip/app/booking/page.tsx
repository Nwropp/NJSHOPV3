'use client'

import { useState } from 'react'
import Link from 'next/link'
import { DataProvider, useData } from '@/lib/data-context'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { CalendarDays, CheckCircle, Sparkles, ArrowRight, User, Gamepad2, MessageSquare, FileText } from 'lucide-react'
import type { BookingFormData } from '@/lib/types'

function BookingContent() {
  const { services, addQueueItem } = useData()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [orderId, setOrderId] = useState('')
  const [formData, setFormData] = useState<BookingFormData>({
    name: '',
    uid: '',
    service: '',
    detail: '',
    contact: '',
  })
  const [errors, setErrors] = useState<Partial<BookingFormData>>({})

  const validate = (): boolean => {
    const newErrors: Partial<BookingFormData> = {}
    if (!formData.name.trim()) newErrors.name = 'Name is required'
    if (!formData.uid.trim()) newErrors.uid = 'Game UID is required'
    if (!formData.service) newErrors.service = 'Please select a service'
    if (!formData.contact.trim()) newErrors.contact = 'Contact information is required'
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!validate()) return

    setIsSubmitting(true)
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    const newOrderId = addQueueItem(formData)
    setOrderId(newOrderId)
    setIsSuccess(true)
    setIsSubmitting(false)
  }

  const resetForm = () => {
    setFormData({ name: '', uid: '', service: '', detail: '', contact: '' })
    setErrors({})
    setIsSuccess(false)
    setOrderId('')
  }

  if (isSuccess) {
    return (
      <section className="py-20 pt-32">
        <div className="container mx-auto px-4">
          <div className="max-w-lg mx-auto glass-card rounded-2xl p-8 text-center">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-green-400 to-emerald-500 flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold mb-4 gradient-text">Booking Successful!</h1>
            <p className="text-muted-foreground mb-6">
              Your order has been placed successfully. We will contact you soon!
            </p>
            <div className="glass rounded-xl p-4 mb-6">
              <div className="text-sm text-muted-foreground mb-1">Your Order ID</div>
              <div className="text-2xl font-bold gradient-text">{orderId}</div>
            </div>
            <div className="flex flex-col gap-3">
              <Link href="/queue">
                <Button className="w-full bg-gradient-to-r from-primary to-accent text-primary-foreground">
                  Check Queue Status
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
              <Button variant="outline" onClick={resetForm} className="w-full">
                Book Another Service
              </Button>
            </div>
          </div>
        </div>
      </section>
    )
  }

  return (
    <section className="py-20 pt-32">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-4">
            <CalendarDays className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">Book Service</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">Book Your Service</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Fill in the form below to place your order. We will contact you to confirm.
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <form onSubmit={handleSubmit} className="glass-card rounded-2xl p-8">
            <div className="space-y-6">
              {/* Name */}
              <div className="space-y-2">
                <Label htmlFor="name" className="flex items-center gap-2">
                  <User className="w-4 h-4 text-primary" />
                  Your Name
                </Label>
                <Input
                  id="name"
                  placeholder="Enter your name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className={`bg-secondary/50 ${errors.name ? 'border-red-500' : ''}`}
                />
                {errors.name && <p className="text-red-500 text-sm">{errors.name}</p>}
              </div>

              {/* UID */}
              <div className="space-y-2">
                <Label htmlFor="uid" className="flex items-center gap-2">
                  <Gamepad2 className="w-4 h-4 text-primary" />
                  Game UID
                </Label>
                <Input
                  id="uid"
                  placeholder="Enter your game UID"
                  value={formData.uid}
                  onChange={(e) => setFormData({ ...formData, uid: e.target.value })}
                  className={`bg-secondary/50 ${errors.uid ? 'border-red-500' : ''}`}
                />
                {errors.uid && <p className="text-red-500 text-sm">{errors.uid}</p>}
              </div>

              {/* Service */}
              <div className="space-y-2">
                <Label htmlFor="service" className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-primary" />
                  Select Service
                </Label>
                <Select 
                  value={formData.service} 
                  onValueChange={(value) => setFormData({ ...formData, service: value })}
                >
                  <SelectTrigger className={`bg-secondary/50 ${errors.service ? 'border-red-500' : ''}`}>
                    <SelectValue placeholder="Choose a service" />
                  </SelectTrigger>
                  <SelectContent>
                    {services.map((service) => (
                      <SelectItem key={service.id} value={service.name}>
                        {service.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.service && <p className="text-red-500 text-sm">{errors.service}</p>}
              </div>

              {/* Detail */}
              <div className="space-y-2">
                <Label htmlFor="detail" className="flex items-center gap-2">
                  <FileText className="w-4 h-4 text-primary" />
                  Service Details
                </Label>
                <Textarea
                  id="detail"
                  placeholder="Describe what you need (e.g., region, level range, specific requirements)"
                  value={formData.detail}
                  onChange={(e) => setFormData({ ...formData, detail: e.target.value })}
                  className="bg-secondary/50 min-h-[100px]"
                />
              </div>

              {/* Contact */}
              <div className="space-y-2">
                <Label htmlFor="contact" className="flex items-center gap-2">
                  <MessageSquare className="w-4 h-4 text-primary" />
                  Contact (Facebook / Discord / Line)
                </Label>
                <Input
                  id="contact"
                  placeholder="FB: Your Name / Discord: user#1234 / Line: @username"
                  value={formData.contact}
                  onChange={(e) => setFormData({ ...formData, contact: e.target.value })}
                  className={`bg-secondary/50 ${errors.contact ? 'border-red-500' : ''}`}
                />
                {errors.contact && <p className="text-red-500 text-sm">{errors.contact}</p>}
              </div>

              {/* Submit */}
              <Button 
                type="submit" 
                className="w-full bg-gradient-to-r from-primary to-accent text-primary-foreground hover:opacity-90 h-12 text-lg"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <div className="w-5 h-5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2" />
                    Processing...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-5 h-5 mr-2" />
                    Submit Booking
                  </>
                )}
              </Button>
            </div>
          </form>

          {/* Help Section */}
          <div className="mt-8 glass-card rounded-2xl p-6 text-center">
            <h3 className="font-bold mb-2">Need Help?</h3>
            <p className="text-muted-foreground text-sm mb-4">
              Check our prices or contact us directly for custom requests
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link href="/prices">
                <Button variant="outline" size="sm">View Prices</Button>
              </Link>
              <Link href="/contact">
                <Button variant="outline" size="sm">Contact Us</Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default function BookingPage() {
  return (
    <DataProvider>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main>
          <BookingContent />
        </main>
        <Footer />
      </div>
    </DataProvider>
  )
}
