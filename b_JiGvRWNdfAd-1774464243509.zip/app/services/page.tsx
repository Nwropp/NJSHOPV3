'use client'

import Image from 'next/image'
import Link from 'next/link'
import { DataProvider, useData } from '@/lib/data-context'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { ChevronRight, Sparkles } from 'lucide-react'

function ServicesContent() {
  const { services } = useData()

  return (
    <section className="py-20 pt-32">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-4">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">All Services</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">Our Services</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Professional gaming services for Genshin Impact. Choose from our wide range of services.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={service.id}
              id={service.id}
              className="glass-card rounded-2xl overflow-hidden hover:scale-[1.02] transition-all duration-300 group"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="relative h-56 overflow-hidden">
                <Image
                  src={service.image}
                  alt={service.name}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
                <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-semibold bg-gradient-to-r ${service.color} text-white`}>
                  From {service.startingPrice} THB
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2 gradient-text">{service.name}</h3>
                <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                  {service.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-primary">{service.unit}</span>
                  <Link href={`/prices?service=${service.id}`}>
                    <Button size="sm" variant="outline" className="group/btn">
                      View Prices
                      <ChevronRight className="w-4 h-4 ml-1 group-hover/btn:translate-x-1 transition-transform" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-16">
          <div className="glass-card rounded-2xl p-8 max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">Ready to get started?</h2>
            <p className="text-muted-foreground mb-6">
              Book your service now and let us handle the rest!
            </p>
            <Link href="/booking">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-primary to-accent text-primary-foreground hover:opacity-90"
              >
                <Sparkles className="w-5 h-5 mr-2" />
                Book Now
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

export default function ServicesPage() {
  return (
    <DataProvider>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main>
          <ServicesContent />
        </main>
        <Footer />
      </div>
    </DataProvider>
  )
}
