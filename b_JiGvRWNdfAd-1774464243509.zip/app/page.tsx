'use client'

import { useEffect, useRef } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { DataProvider } from '@/lib/data-context'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Sparkles, ChevronRight, Shield, Clock, Trophy, Users, Gamepad2, Zap, Star, Heart } from 'lucide-react'
import { services } from '@/lib/data'

const stats = [
  { icon: Trophy, value: '5K+', label: 'Orders Completed' },
  { icon: Users, value: '2K+', label: 'Happy Customers' },
  { icon: Clock, value: '24/7', label: 'Support' },
  { icon: Shield, value: '100%', label: 'Secure' },
]

const features = [
  { icon: Zap, title: 'Fast Service', description: 'Quick turnaround time for all orders' },
  { icon: Shield, title: 'Safe & Secure', description: 'Your account is in safe hands' },
  { icon: Star, title: 'Professional', description: 'Experienced team of players' },
  { icon: Heart, title: 'Customer Care', description: 'Friendly support always available' },
]

function HeroSection() {
  const starsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const container = starsRef.current
    if (!container) return

    for (let i = 0; i < 50; i++) {
      const star = document.createElement('div')
      star.className = 'absolute rounded-full bg-primary/30'
      star.style.width = `${Math.random() * 3 + 1}px`
      star.style.height = star.style.width
      star.style.left = `${Math.random() * 100}%`
      star.style.top = `${Math.random() * 100}%`
      star.style.animation = `float ${Math.random() * 3 + 2}s ease-in-out infinite`
      star.style.animationDelay = `${Math.random() * 2}s`
      container.appendChild(star)
    }

    return () => {
      while (container.firstChild) {
        container.removeChild(container.firstChild)
      }
    }
  }, [])

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      <div ref={starsRef} className="absolute inset-0 pointer-events-none" />
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-background pointer-events-none" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/20 rounded-full blur-3xl pointer-events-none" />

      <div className="container mx-auto px-4 py-20 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-8 animate-fade-in-up">
            <Gamepad2 className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">Premium Gaming Services</span>
          </div>

          <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-fade-in-up" style={{ animationDelay: '0.1s' }}>
            Welcome to
            <span className="block gradient-text text-glow">NJ Shop</span>
          </h1>

          <p 
            className="text-lg md:text-xl text-muted-foreground mb-8 max-w-2xl mx-auto animate-fade-in-up"
            style={{ animationDelay: '0.2s' }}
          >
            Professional gaming services for Genshin Impact. Quest completion, leveling, 
            farming, gem services, and more. Fast, secure, and affordable.
          </p>

          <div 
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16 animate-fade-in-up"
            style={{ animationDelay: '0.3s' }}
          >
            <Link href="/booking">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-primary to-accent text-primary-foreground hover:opacity-90 transition-all glow-primary px-8"
              >
                <Sparkles className="w-5 h-5 mr-2" />
                Book Now
              </Button>
            </Link>
            <Link href="/prices">
              <Button variant="outline" size="lg" className="group">
                View Prices
                <ChevronRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </div>

          <div 
            className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 animate-fade-in-up"
            style={{ animationDelay: '0.4s' }}
          >
            {stats.map((stat, index) => (
              <div 
                key={stat.label}
                className="glass-card rounded-xl p-4 md:p-6 text-center hover:scale-105 transition-transform"
                style={{ animationDelay: `${0.5 + index * 0.1}s` }}
              >
                <stat.icon className="w-6 h-6 md:w-8 md:h-8 text-primary mx-auto mb-2" />
                <div className="text-2xl md:text-3xl font-bold gradient-text">{stat.value}</div>
                <div className="text-xs md:text-sm text-muted-foreground">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 rounded-full border-2 border-muted-foreground/50 flex justify-center pt-2">
          <div className="w-1 h-3 rounded-full bg-primary animate-pulse" />
        </div>
      </div>
    </section>
  )
}

function FeaturedServicesSection() {
  return (
    <section className="py-20 bg-secondary/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 gradient-text">Our Services</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Professional gaming services tailored to your needs
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {services.slice(0, 4).map((service, index) => (
            <Link 
              key={service.id} 
              href={`/services#${service.id}`}
              className="glass-card rounded-xl overflow-hidden hover:scale-105 transition-all duration-300 group"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="relative h-48 overflow-hidden">
                <Image
                  src={service.image}
                  alt={service.name}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4">
                  <h3 className="text-lg font-bold text-foreground">{service.name}</h3>
                  <p className="text-sm text-primary">
                    From {service.startingPrice} THB {service.unit}
                  </p>
                </div>
              </div>
            </Link>
          ))}
        </div>

        <div className="text-center mt-10">
          <Link href="/services">
            <Button variant="outline" size="lg" className="group">
              View All Services
              <ChevronRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}

function WhyChooseUsSection() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 gradient-text">Why Choose Us?</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            We provide the best gaming service experience
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => (
            <div 
              key={feature.title}
              className="glass-card rounded-xl p-6 text-center hover:scale-105 transition-transform"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center mx-auto mb-4">
                <feature.icon className="w-7 h-7 text-primary-foreground" />
              </div>
              <h3 className="text-lg font-bold mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function CTASection() {
  return (
    <section className="py-20 bg-gradient-to-r from-primary/20 to-accent/20">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Get Started?</h2>
        <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
          Book your service now and experience professional gaming assistance
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <Link href="/booking">
            <Button 
              size="lg" 
              className="bg-gradient-to-r from-primary to-accent text-primary-foreground hover:opacity-90 px-8"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Book Now
            </Button>
          </Link>
          <Link href="/contact">
            <Button variant="outline" size="lg">
              Contact Us
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}

export default function HomePage() {
  return (
    <DataProvider>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main>
          <HeroSection />
          <FeaturedServicesSection />
          <WhyChooseUsSection />
          <CTASection />
        </main>
        <Footer />
      </div>
    </DataProvider>
  )
}
