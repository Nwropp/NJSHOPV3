'use client'

import { useState, useEffect, Suspense } from 'react'
import { useSearchParams } from 'next/navigation'
import { DataProvider, useData } from '@/lib/data-context'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Tag, Sparkles } from 'lucide-react'

function PricesContent() {
  const searchParams = useSearchParams()
  const serviceParam = searchParams.get('service')
  const { services, prices } = useData()
  const [activeTab, setActiveTab] = useState(serviceParam || services[0]?.id || '')

  useEffect(() => {
    if (serviceParam && services.find(s => s.id === serviceParam)) {
      setActiveTab(serviceParam)
    }
  }, [serviceParam, services])

  const getPricesForService = (serviceId: string) => {
    return prices.filter(price => price.serviceId === serviceId)
  }

  const getService = (serviceId: string) => {
    return services.find(s => s.id === serviceId)
  }

  return (
    <section className="py-20 pt-32">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-4">
            <Tag className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">Price List</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">Our Prices</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Transparent pricing for all our services. All prices are in Thai Baht (THB).
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex justify-center mb-8 overflow-x-auto pb-2">
            <TabsList className="glass inline-flex h-auto p-1 flex-wrap justify-center gap-1">
              {services.map((service) => (
                <TabsTrigger 
                  key={service.id}
                  value={service.id}
                  className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground px-4 py-2 text-sm whitespace-nowrap"
                >
                  {service.name}
                </TabsTrigger>
              ))}
            </TabsList>
          </div>

          {services.map((service) => (
            <TabsContent key={service.id} value={service.id} className="mt-0">
              <div className="glass-card rounded-2xl p-6 md:p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${service.color} flex items-center justify-center`}>
                    <Sparkles className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold">{service.name}</h2>
                    <p className="text-sm text-muted-foreground">{service.description}</p>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border">
                        <th className="text-left py-4 px-4 text-muted-foreground font-medium">Service</th>
                        <th className="text-right py-4 px-4 text-muted-foreground font-medium">Price (THB)</th>
                        <th className="text-left py-4 px-4 text-muted-foreground font-medium hidden md:table-cell">Note</th>
                      </tr>
                    </thead>
                    <tbody>
                      {getPricesForService(service.id).map((price, index) => (
                        <tr 
                          key={price.id}
                          className="border-b border-border/50 hover:bg-secondary/50 transition-colors"
                        >
                          <td className="py-4 px-4">
                            <span className="font-medium">{price.name}</span>
                            {price.unit && (
                              <span className="text-muted-foreground text-sm ml-2">{price.unit}</span>
                            )}
                          </td>
                          <td className="py-4 px-4 text-right">
                            <span className="text-lg font-bold text-primary">{price.price}</span>
                            {price.unit && price.unit !== '' && (
                              <span className="text-muted-foreground text-sm ml-1">{price.unit}</span>
                            )}
                          </td>
                          <td className="py-4 px-4 hidden md:table-cell">
                            {price.description && (
                              <Badge variant="secondary" className="text-xs">
                                {price.description}
                              </Badge>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {getPricesForService(service.id).length === 0 && (
                  <div className="text-center py-12 text-muted-foreground">
                    No prices available for this service yet.
                  </div>
                )}
              </div>
            </TabsContent>
          ))}
        </Tabs>

        <div className="mt-12 glass-card rounded-2xl p-6 text-center">
          <h3 className="text-lg font-bold mb-2">Need a custom quote?</h3>
          <p className="text-muted-foreground text-sm">
            Contact us on Facebook for special requests or bulk orders!
          </p>
        </div>
      </div>
    </section>
  )
}

function PricesPageContent() {
  return (
    <Suspense fallback={<div className="py-20 pt-32 text-center">Loading...</div>}>
      <PricesContent />
    </Suspense>
  )
}

export default function PricesPage() {
  return (
    <DataProvider>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main>
          <PricesPageContent />
        </main>
        <Footer />
      </div>
    </DataProvider>
  )
}
