'use client'

import Link from 'next/link'
import { DataProvider } from '@/lib/data-context'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { 
  MessageCircle, 
  Facebook, 
  Clock, 
  Sparkles,
  ExternalLink,
  Heart,
  ShieldCheck,
  Zap
} from 'lucide-react'

const contactMethods = [
  {
    icon: Facebook,
    name: 'Facebook',
    value: 'Nawaphon Jamrasrak',
    description: 'Main contact for orders and inquiries',
    link: 'https://www.facebook.com/Nawaphon.Jamrasrak',
    color: 'from-blue-500 to-blue-600',
  },
  {
    icon: MessageCircle,
    name: 'Line',
    value: '@njshop',
    description: 'Quick responses for urgent matters',
    link: '#',
    color: 'from-green-500 to-green-600',
  },
  {
    icon: Clock,
    name: 'Service Hours',
    value: '10:00 - 24:00',
    description: 'Available every day',
    link: null,
    color: 'from-purple-500 to-purple-600',
  },
]

const features = [
  { icon: Zap, title: 'Fast Response', description: 'Usually reply within 30 minutes' },
  { icon: ShieldCheck, title: 'Safe Service', description: 'Your account is secure with us' },
  { icon: Heart, title: 'Friendly Support', description: 'We are here to help you' },
]

function ContactContent() {
  return (
    <section className="py-20 pt-32">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-4">
            <MessageCircle className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">Get in Touch</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">Contact Us</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Have questions? We are here to help! Reach out through any of the channels below.
          </p>
        </div>

        {/* Contact Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-16">
          {contactMethods.map((method, index) => (
            <div 
              key={method.name}
              className="glass-card rounded-2xl p-6 text-center hover:scale-[1.02] transition-all duration-300"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${method.color} flex items-center justify-center mx-auto mb-4`}>
                <method.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-bold mb-1">{method.name}</h3>
              <p className="text-xl gradient-text font-medium mb-2">{method.value}</p>
              <p className="text-sm text-muted-foreground mb-4">{method.description}</p>
              {method.link && (
                <a href={method.link} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" size="sm" className="group">
                    Open
                    <ExternalLink className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </a>
              )}
            </div>
          ))}
        </div>

        {/* Features */}
        <div className="glass-card rounded-2xl p-8 max-w-4xl mx-auto mb-16">
          <h2 className="text-2xl font-bold text-center mb-8">Why Contact Us?</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {features.map((feature, index) => (
              <div key={feature.title} className="text-center">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-3">
                  <feature.icon className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-bold mb-1">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* FAQ Section */}
        <div className="max-w-2xl mx-auto">
          <h2 className="text-2xl font-bold text-center mb-8">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {[
              { q: 'How do I place an order?', a: 'You can book through our website or contact us directly on Facebook.' },
              { q: 'What payment methods do you accept?', a: 'We accept bank transfer and PromptPay. Contact us for details.' },
              { q: 'How long does each service take?', a: 'It depends on the service. We will give you an estimated time when you book.' },
              { q: 'Is my account safe?', a: 'Yes! We take account security very seriously and have never had any issues.' },
            ].map((faq, index) => (
              <div key={index} className="glass-card rounded-xl p-5">
                <h3 className="font-bold mb-2">{faq.q}</h3>
                <p className="text-muted-foreground text-sm">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <div className="glass-card rounded-2xl p-8 max-w-2xl mx-auto bg-gradient-to-r from-primary/10 to-accent/10">
            <h2 className="text-2xl font-bold mb-4">Ready to Get Started?</h2>
            <p className="text-muted-foreground mb-6">
              Book your service now or check out our prices first!
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/booking">
                <Button 
                  size="lg" 
                  className="bg-gradient-to-r from-primary to-accent text-primary-foreground hover:opacity-90"
                >
                  <Sparkles className="w-5 h-5 mr-2" />
                  Book Now
                </Button>
              </Link>
              <Link href="/prices">
                <Button variant="outline" size="lg">
                  View Prices
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default function ContactPage() {
  return (
    <DataProvider>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main>
          <ContactContent />
        </main>
        <Footer />
      </div>
    </DataProvider>
  )
}
