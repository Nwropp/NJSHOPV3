'use client'

import { useState } from 'react'
import Link from 'next/link'
import { DataProvider, useData } from '@/lib/data-context'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Clock, Search, Users, CheckCircle, Loader2, Sparkles, RefreshCcw } from 'lucide-react'

const statusConfig = {
  'waiting': { label: 'Waiting', color: 'bg-yellow-500/20 text-yellow-500 border-yellow-500/50', icon: Clock },
  'in-progress': { label: 'In Progress', color: 'bg-blue-500/20 text-blue-500 border-blue-500/50', icon: Loader2 },
  'completed': { label: 'Completed', color: 'bg-green-500/20 text-green-500 border-green-500/50', icon: CheckCircle },
}

function QueueContent() {
  const { queue } = useData()
  const [searchTerm, setSearchTerm] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('all')

  const filteredQueue = queue.filter(item => {
    const matchesSearch = 
      item.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.uid.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const stats = {
    total: queue.length,
    waiting: queue.filter(q => q.status === 'waiting').length,
    inProgress: queue.filter(q => q.status === 'in-progress').length,
    completed: queue.filter(q => q.status === 'completed').length,
  }

  return (
    <section className="py-20 pt-32">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass mb-4">
            <Users className="w-4 h-4 text-primary" />
            <span className="text-sm text-muted-foreground">Queue Status</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4 gradient-text">Check Your Queue</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Track the status of your order in real-time
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="glass-card rounded-xl p-4 text-center">
            <div className="text-3xl font-bold gradient-text">{stats.total}</div>
            <div className="text-sm text-muted-foreground">Total Orders</div>
          </div>
          <div className="glass-card rounded-xl p-4 text-center">
            <div className="text-3xl font-bold text-yellow-500">{stats.waiting}</div>
            <div className="text-sm text-muted-foreground">Waiting</div>
          </div>
          <div className="glass-card rounded-xl p-4 text-center">
            <div className="text-3xl font-bold text-blue-500">{stats.inProgress}</div>
            <div className="text-sm text-muted-foreground">In Progress</div>
          </div>
          <div className="glass-card rounded-xl p-4 text-center">
            <div className="text-3xl font-bold text-green-500">{stats.completed}</div>
            <div className="text-sm text-muted-foreground">Completed</div>
          </div>
        </div>

        {/* Search and Filter */}
        <div className="glass-card rounded-2xl p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                placeholder="Search by Order ID, Name, or UID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-secondary/50"
              />
            </div>
            <div className="flex gap-2">
              {['all', 'waiting', 'in-progress', 'completed'].map((status) => (
                <Button
                  key={status}
                  variant={statusFilter === status ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setStatusFilter(status)}
                  className={statusFilter === status ? 'bg-primary' : ''}
                >
                  {status === 'all' ? 'All' : status === 'in-progress' ? 'In Progress' : status.charAt(0).toUpperCase() + status.slice(1)}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Queue List */}
        <div className="space-y-4">
          {filteredQueue.length === 0 ? (
            <div className="glass-card rounded-2xl p-12 text-center">
              <Search className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
              <h2 className="text-xl font-bold mb-2">No orders found</h2>
              <p className="text-muted-foreground">
                {searchTerm ? 'Try a different search term' : 'No orders in the queue yet'}
              </p>
            </div>
          ) : (
            filteredQueue.map((item, index) => {
              const config = statusConfig[item.status]
              const StatusIcon = config.icon
              return (
                <div 
                  key={item.id}
                  className="glass-card rounded-xl p-6 hover:scale-[1.01] transition-all duration-300"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center text-primary-foreground font-bold shrink-0">
                        {index + 1}
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-bold text-lg">{item.id}</span>
                          <Badge variant="outline" className={config.color}>
                            <StatusIcon className={`w-3 h-3 mr-1 ${item.status === 'in-progress' ? 'animate-spin' : ''}`} />
                            {config.label}
                          </Badge>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {item.name} • UID: {item.uid}
                        </div>
                        <div className="text-sm mt-1">
                          <span className="text-primary font-medium">{item.service}</span>
                          {item.detail && <span className="text-muted-foreground"> - {item.detail}</span>}
                        </div>
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground text-right">
                      <div>Created: {new Date(item.createdAt).toLocaleDateString()}</div>
                      <div>Updated: {new Date(item.updatedAt).toLocaleDateString()}</div>
                    </div>
                  </div>
                </div>
              )
            })
          )}
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <div className="glass-card rounded-2xl p-8 max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">Want to place an order?</h2>
            <p className="text-muted-foreground mb-6">
              Book your service now and track it here!
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/booking">
                <Button 
                  size="lg" 
                  className="bg-gradient-to-r from-primary to-accent text-primary-foreground hover:opacity-90"
                >
                  <Sparkles className="w-5 h-5 mr-2" />
                  Book Now
                </Button>
              </Link>
              <Button 
                size="lg" 
                variant="outline"
                onClick={() => window.location.reload()}
              >
                <RefreshCcw className="w-5 h-5 mr-2" />
                Refresh
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default function QueuePage() {
  return (
    <DataProvider>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main>
          <QueueContent />
        </main>
        <Footer />
      </div>
    </DataProvider>
  )
}
